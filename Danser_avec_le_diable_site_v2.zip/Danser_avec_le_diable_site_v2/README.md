# Danser avec le diable — site vitrine

Site vitrine responsive en HTML, CSS et JavaScript, sans framework et sans dépendance serveur.

## Fichiers
- `index.html` : contenu et structure
- `styles.css` : design responsive noir / rouge profond / blanc cassé
- `script.js` : menu mobile, année automatique et formulaire de contact par e-mail
- `assets/` : visuel de couverture fourni avec le projet

## Avant publication
1. Vérifier le texte du livre et remplacer les extraits provisoires par les passages définitifs autorisés.
2. Remplacer `contact@exemple.fr` dans `index.html` et `script.js` par l'adresse e-mail que tu souhaites afficher.
3. Vérifier que tu disposes des droits nécessaires sur toutes les images utilisées.
4. Ajouter les mentions légales et la politique de confidentialité adaptées à ton activité avant toute collecte de données ou vente.
5. Ne pas présenter les prix ou la disponibilité comme définitifs tant qu'ils ne sont pas confirmés.

## Tester sur ton ordinateur
Double-clique sur `index.html` pour l'ouvrir dans un navigateur. Le site fonctionne sans compilation.

## Publier gratuitement avec GitHub Pages
1. Crée un compte sur https://github.com/ si tu n'en as pas.
2. Crée un nouveau dépôt public nommé `danser-avec-le-diable`.
3. Envoie dans le dépôt tous les fichiers de ce dossier, en conservant la structure et le dossier `assets`.
4. Dans le dépôt, ouvre **Settings → Pages**.
5. Dans **Build and deployment**, sélectionne **Deploy from a branch**, choisis `main` et `/ (root)`, puis enregistre.
6. Après le déploiement, GitHub indiquera une adresse publique du type `https://TON-PSEUDO.github.io/danser-avec-le-diable/`.

L'hébergement GitHub Pages est adapté à un site vitrine statique. Il ne gère pas directement les paiements, les commandes, les expéditions ou les téléchargements payants : ces fonctions demanderont plus tard une solution de boutique ou de paiement séparée.

## Important
Le formulaire actuel ouvre l'application e-mail du visiteur ; il ne stocke aucune adresse et ne constitue pas une newsletter automatisée. Il utilise une adresse d'exemple à remplacer avant publication.
